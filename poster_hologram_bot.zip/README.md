# Exotic Hologram Poster Bot

This app lets you:
- Upload any poster image
- Apply exotic hologram effects
- Export as Print-Ready PDF, Animated GIF, or MP4

## Run locally

```bash
pip install -r requirements.txt
streamlit run poster_bot.py
```

Open http://localhost:8501 in your browser.
