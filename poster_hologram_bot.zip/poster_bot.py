import streamlit as st
from PIL import Image, ImageEnhance
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
import tempfile, io, cv2
import numpy as np

def check_dpi(img, target_size=(18, 24), dpi=300):
    width_px, height_px = img.size
    req_width = target_size[0] * dpi
    req_height = target_size[1] * dpi
    return width_px >= req_width and height_px >= req_height

def apply_hologram_effect(img, style="Cyberpunk City"):
    img = img.convert("RGBA")
    gradient = Image.new("RGBA", img.size, (0,0,0,0))
    for y in range(img.size[1]):
        r = int(128 + 127 * (y / img.size[1]))
        b = int(255 * (1 - y / img.size[1]))
        gradient.putpixel((0, y), (r, 0, b, 80))
    gradient = gradient.resize(img.size)
    img = Image.alpha_composite(img, gradient)
    enhancer = ImageEnhance.Brightness(img)
    img = enhancer.enhance(1.2)
    return img

def to_print_ready_pdf(img, poster_size=(18,24), dpi=300):
    temp_img = tempfile.NamedTemporaryFile(delete=False, suffix=".jpg")
    img = img.convert("CMYK")
    img = img.resize((poster_size[0]*dpi, poster_size[1]*dpi), Image.LANCZOS)
    img.save(temp_img.name, dpi=(dpi, dpi))
    pdf_path = tempfile.NamedTemporaryFile(delete=False, suffix=".pdf").name
    c = canvas.Canvas(pdf_path, pagesize=(poster_size[0]*inch, poster_size[1]*inch))
    c.drawImage(temp_img.name, 0, 0, poster_size[0]*inch, poster_size[1]*inch)
    c.save()
    return pdf_path

def make_hologram_gif(img, frames=10):
    imgs = []
    for i in range(frames):
        frame = img.copy()
        enhancer = ImageEnhance.Brightness(frame)
        flicker = 1 + (0.2 * ((i % 2) - 0.5))
        frame = enhancer.enhance(flicker)
        imgs.append(frame)
    gif_path = tempfile.NamedTemporaryFile(delete=False, suffix=".gif").name
    imgs[0].save(gif_path, save_all=True, append_images=imgs[1:], duration=150, loop=0)
    return gif_path

def make_hologram_mp4(img, frames=30, fps=10):
    width, height = img.size
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    mp4_path = tempfile.NamedTemporaryFile(delete=False, suffix=".mp4").name
    out = cv2.VideoWriter(mp4_path, fourcc, fps, (width, height))
    for i in range(frames):
        frame = img.copy()
        enhancer = ImageEnhance.Brightness(frame)
        flicker = 1 + (0.2 * ((i % 2) - 0.5))
        frame = enhancer.enhance(flicker)
        frame_cv = cv2.cvtColor(np.array(frame.convert("RGB")), cv2.COLOR_RGB2BGR)
        out.write(frame_cv)
    out.release()
    return mp4_path

st.title("🖼️ Exotic Hologram Poster Bot")
uploaded_file = st.file_uploader("Upload your poster image", type=["jpg","jpeg","png","tif"])
style = st.selectbox("Choose hologram style", ["Cyberpunk City", "Bioluminescent Jungle", "Crystal Planet", "Orbital Station"])
output_type = st.radio("Output Type", ["Print PDF", "Digital GIF", "Digital MP4"])

if uploaded_file:
    img = Image.open(uploaded_file)
    st.image(img, caption="Original Upload", use_column_width=True)
    if st.button("Convert"):
        holo_img = apply_hologram_effect(img, style)
        st.image(holo_img, caption=f"Hologram Style: {style}", use_column_width=True)
        if output_type == "Print PDF":
            pdf_file = to_print_ready_pdf(holo_img)
            with open(pdf_file, "rb") as f:
                st.download_button("⬇️ Download Print-Ready PDF", f, file_name="poster_ready.pdf")
        elif output_type == "Digital GIF":
            gif_file = make_hologram_gif(holo_img)
            with open(gif_file, "rb") as f:
                st.download_button("⬇️ Download Animated Hologram (GIF)", f, file_name="poster_hologram.gif")
        elif output_type == "Digital MP4":
            mp4_file = make_hologram_mp4(holo_img)
            with open(mp4_file, "rb") as f:
                st.download_button("⬇️ Download Animated Hologram (MP4)", f, file_name="poster_hologram.mp4")
